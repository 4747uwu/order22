function OnStableStudy(studyId, tags, metadata)
   print('Auto-forwarding stable study: ' .. studyId)

   -- Get all instances in the study
   local instances = ParseJson(RestApiGet('/studies/' .. studyId .. '/instances'))

   for _, instance in ipairs(instances) do
      local instanceId = instance['ID']
      print('Sending instance: ' .. instanceId)

      local success = SendToModality(instanceId, 'RECIEVER_AET')
      if success then
         print('SUCCESS: Sent instance to RECIEVER_AET')
      else
         print('ERROR: Failed to send instance ' .. instanceId .. ' to RECIEVER_AET')
      end
   end
end
